<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('patient_identifiers', function (Blueprint $t) {
            $t->id();
            $t->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();
            $t->string('type', 50); // NID, PASSPORT, BIRTH_CERT, HOSPITAL_ID, OTHER
            $t->string('value')->index();
            $t->boolean('is_primary')->default(false);
            $t->timestamps();

            $t->unique(['patient_id', 'type', 'value']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patient_identifiers');
    }
};
