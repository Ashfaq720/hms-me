<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('billing_requests', function (Blueprint $t) {
            $t->id();
            $t->string('reference_type', 20); // REGISTRATION/APPOINTMENT/VISIT/IPD_ADMISSION
            $t->unsignedBigInteger('reference_id');

            $t->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $t->string('bill_type', 20); // REGISTRATION/OPD/APPOINTMENT/ADMISSION/EMERGENCY
            $t->json('payload');         // items[], payments[] etc
            $t->string('status', 20)->default('PENDING'); // PENDING/SENT/FAILED/SUCCESS
            $t->text('error_message')->nullable();

            $t->string('external_bill_id')->nullable();  // from Billing service
            $t->string('external_receipt_no')->nullable();

            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();

            $t->timestamps();

            $t->index(['reference_type', 'reference_id']);
            $t->index(['status', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('billing_requests');
    }
};
