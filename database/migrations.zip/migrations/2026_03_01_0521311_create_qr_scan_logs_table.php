<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('qr_scan_logs', function (Blueprint $t) {
            $t->id();
            $t->string('identifier'); // scanned card_id or token identifier
            $t->foreignId('patient_id')->nullable()->constrained('patients')->nullOnDelete();
            $t->string('context', 40); // FRONT_DESK_REG / CHECKIN / ER_INTAKE / KIOSK / GATE
            $t->string('result', 20);  // SUCCESS/NOT_FOUND/BLOCKED/EXPIRED/ERROR
            $t->foreignId('scanned_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->dateTime('scanned_at');
            $t->timestamps();

            $t->index(['context', 'scanned_at']);
            $t->index(['patient_id', 'scanned_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('qr_scan_logs');
    }
};
