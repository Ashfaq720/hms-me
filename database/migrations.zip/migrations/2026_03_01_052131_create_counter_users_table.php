<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('counter_users', function (Blueprint $t) {
            $t->id();
            $t->foreignId('counter_id')->constrained('front_desk_counters')->cascadeOnDelete();
            $t->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $t->dateTime('assigned_from');
            $t->dateTime('assigned_to')->nullable();
            $t->boolean('is_active')->default(true);
            $t->timestamps();

            $t->index(['counter_id', 'user_id', 'is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('counter_users');
    }
};
