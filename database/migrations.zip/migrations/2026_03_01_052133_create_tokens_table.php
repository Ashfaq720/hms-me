<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tokens', function (Blueprint $t): void {
            $t->id();

            $t->string('token_no');            // D01-001 style (generated)
            $t->date('token_date');

            $t->foreignId('doctor_id')->constrained('doctors')->restrictOnDelete();
            $t->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $t->foreignId('patient_id')->constrained('patients')->restrictOnDelete();

            $t->foreignId('appointment_id')->nullable()->constrained('appointments')->nullOnDelete();
            $t->foreignId('doctor_shift_id')->nullable()->constrained('doctor_shifts')->nullOnDelete();

            $t->string('visit_type', 10)->default('OPD'); // OPD/ER (if used)
            $t->string('status', 30)->default('WAITING'); // WAITING/CALLED/IN_CONSULTATION/COMPLETED/SKIPPED/CANCELLED/NO_SHOW
            $t->string('priority_level', 20)->default('NORMAL'); // NORMAL/EMERGENCY/HIGH/CRITICAL
            $t->text('priority_reason')->nullable();

            $t->dateTime('generated_at')->nullable();
            $t->dateTime('checked_in_at')->nullable();
            $t->dateTime('called_at')->nullable();
            $t->dateTime('served_at')->nullable();

            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();

            $t->timestamps();

            $t->unique(['token_date', 'doctor_id', 'token_no']);
            $t->index(['doctor_id', 'token_date', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tokens');
    }
};
