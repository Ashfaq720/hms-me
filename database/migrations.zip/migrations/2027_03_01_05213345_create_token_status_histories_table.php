<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('token_status_histories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('token_id')->constrained('tokens')->cascadeOnDelete();
            $t->string('from_status', 30)->nullable();
            $t->string('to_status', 30);
            $t->dateTime('changed_at');
            $t->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->text('reason')->nullable();
            $t->timestamps();

            $t->index(['token_id', 'changed_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('token_status_histories');
    }
};
