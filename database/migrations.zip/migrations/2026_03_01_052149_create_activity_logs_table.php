<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('activity_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->string('activity_type', 60); // CHECKIN/TOKEN_CREATE/CANCEL/OVERRIDE...
            $t->string('reference_type', 20)->nullable();
            $t->unsignedBigInteger('reference_id')->nullable();
            $t->dateTime('activity_at');
            $t->timestamps();

            $t->index(['activity_type', 'activity_at']);
            $t->index(['counter_id', 'activity_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('activity_logs');
    }
};
