<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('priority_change_histories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('visit_id')->constrained('visits')->cascadeOnDelete();
            $t->string('from_priority', 20)->nullable();
            $t->string('to_priority', 20);
            $t->text('reason')->nullable();
            $t->foreignId('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTime('changed_at');
            $t->timestamps();

            $t->index(['visit_id', 'changed_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('priority_change_histories');
    }
};
