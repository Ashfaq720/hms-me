<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();

            $t->string('action', 100);
            $t->string('auditable_type', 50); // PATIENT/APPOINTMENT/TOKEN/VISIT/DOCUMENT/IPD...
            $t->unsignedBigInteger('auditable_id');

            $t->json('old_values')->nullable();
            $t->json('new_values')->nullable();

            $t->string('ip_address')->nullable();
            $t->text('user_agent')->nullable();

            $t->timestamps();

            $t->index(['auditable_type', 'auditable_id']);
            $t->index(['user_id', 'action']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
    }
};
