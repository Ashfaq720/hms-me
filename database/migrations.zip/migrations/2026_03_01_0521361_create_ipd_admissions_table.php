<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ipd_admissions', function (Blueprint $t) {
            $t->id();
            $t->string('admission_no')->unique();

            $t->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $t->foreignId('admitting_doctor_id')->constrained('doctors')->restrictOnDelete();
            $t->foreignId('department_id')->constrained('departments')->restrictOnDelete();

            $t->string('source_type', 20)->nullable(); // OPD_VISIT/ER_VISIT/REFERRAL
            $t->unsignedBigInteger('source_id')->nullable();

            $t->string('admission_type', 20); // EMERGENCY/PLANNED
            $t->string('status', 30)->default('REQUESTED'); // REQUESTED/APPROVED/ADMITTED/DISCHARGED/CANCELLED

            $t->dateTime('requested_at');
            $t->foreignId('requested_by')->nullable()->constrained('users')->nullOnDelete();

            $t->dateTime('approved_at')->nullable();
            $t->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $t->text('approval_notes')->nullable();

            $t->dateTime('admitted_at')->nullable();
            $t->dateTime('discharged_at')->nullable();

            $t->foreignId('ward_id')->nullable()->constrained('wards')->nullOnDelete();
            $t->foreignId('bed_id')->nullable()->constrained('beds')->nullOnDelete();

            $t->text('remarks')->nullable();
            $t->timestamps();

            $t->index(['patient_id', 'status']);
            $t->index(['status', 'requested_at']);
            $t->index(['source_type', 'source_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ipd_admissions');
    }
};
