<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('billing_syncs', function (Blueprint $t) {
            $t->id();
            $t->string('reference_type', 20);
            $t->unsignedBigInteger('reference_id');

            $t->string('external_bill_id')->nullable();
            $t->string('receipt_no')->nullable();
            $t->string('billing_status', 20)->default('UNPAID'); // UNPAID/PARTIAL/PAID/CANCELLED
            $t->decimal('total_amount', 12, 2)->default(0);
            $t->decimal('paid_amount', 12, 2)->default(0);
            $t->decimal('due_amount', 12, 2)->default(0);

            $t->dateTime('last_synced_at')->nullable();
            $t->timestamps();

            $t->unique(['reference_type', 'reference_id']);
            $t->index(['billing_status', 'last_synced_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('billing_syncs');
    }
};
