<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('processing_locks', function (Blueprint $t) {
            $t->id();
            $t->string('lockable_type', 50); // APPOINTMENT/TOKEN/VISIT/IPD_ADMISSION/PATIENT
            $t->unsignedBigInteger('lockable_id');
            $t->foreignId('locked_by')->constrained('users')->restrictOnDelete();
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->uuid('lock_token')->unique();
            $t->dateTime('locked_at');
            $t->dateTime('expires_at')->nullable();
            $t->timestamps();

            $t->unique(['lockable_type', 'lockable_id']);
            $t->index(['locked_by', 'locked_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('processing_locks');
    }
};
