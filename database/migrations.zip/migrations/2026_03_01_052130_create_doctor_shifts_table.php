<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('doctor_shifts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('doctor_id')->constrained('doctors')->cascadeOnDelete();
            $t->unsignedTinyInteger('day_of_week'); // 0-6
            $t->time('start_time');
            $t->time('end_time');

            $t->unsignedSmallInteger('slot_minutes')->default(10);
            $t->unsignedInteger('max_per_slot')->nullable();
            $t->unsignedInteger('max_per_shift')->nullable();
            $t->unsignedInteger('max_per_day')->nullable();

            $t->unsignedInteger('max_prebook')->nullable();
            $t->unsignedInteger('max_walkin')->nullable();

            $t->boolean('has_emergency_buffer')->default(false); // emergency buffer slots
            $t->boolean('is_active')->default(true);
            $t->timestamps();

            $t->index(['doctor_id', 'day_of_week', 'is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('doctor_shifts');
    }
};
