<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cashless_eligibilities', function (Blueprint $t) {
            $t->id();
            $t->string('reference_type', 20); // VISIT/IPD_ADMISSION/APPOINTMENT
            $t->unsignedBigInteger('reference_id');
            $t->string('eligibility_status', 20); // ELIGIBLE/PENDING/NOT_ELIGIBLE
            $t->string('rule_hit', 100)->nullable(); // which rule applied
            $t->text('reason')->nullable();
            $t->dateTime('checked_at');
            $t->foreignId('checked_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();

            $t->index(['reference_type', 'reference_id']);
            $t->index(['eligibility_status', 'checked_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cashless_eligibilities');
    }
};
