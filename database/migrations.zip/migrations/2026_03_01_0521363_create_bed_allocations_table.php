<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bed_allocations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('ipd_admission_id')->constrained('ipd_admissions')->cascadeOnDelete();
            $t->foreignId('bed_id')->constrained('beds')->restrictOnDelete();
            $t->dateTime('allocated_from');
            $t->dateTime('allocated_to')->nullable();
            $t->string('status', 20)->default('ACTIVE'); // ACTIVE/RELEASED/TRANSFERRED
            $t->timestamps();

            $t->index(['bed_id', 'status']);
            $t->index(['ipd_admission_id', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bed_allocations');
    }
};
