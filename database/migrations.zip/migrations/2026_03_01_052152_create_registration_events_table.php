<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('registration_events', function (Blueprint $t) {
            $t->id();
            $t->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $t->string('registration_type', 20)->default('NEW'); // NEW/RE_REG
            $t->foreignId('counter_id')->nullable()->constrained('front_desk_counters')->nullOnDelete();
            $t->foreignId('registered_by')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTime('registered_at');
            $t->string('status', 20)->default('COMPLETED'); // COMPLETED/PENDING_BILLING/CANCELLED
            $t->text('remarks')->nullable();
            $t->timestamps();

            $t->index(['registered_at', 'status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('registration_events');
    }
};
