<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bed_requests', function (Blueprint $t) {
            $t->id();
            $t->foreignId('ipd_admission_id')->constrained('ipd_admissions')->cascadeOnDelete();

            $t->string('preferred_ward_type', 20)->nullable(); // GENERAL/CABIN/ICU/HDU
            $t->string('preferred_bed_type', 20)->nullable();
            $t->string('gender_restriction', 10)->nullable();
            $t->json('special_needs')->nullable(); // isolation/oxygen/monitor etc
            $t->string('priority', 20)->default('NORMAL'); // derived from admission type

            $t->foreignId('ward_id')->nullable()->constrained('wards')->nullOnDelete();
            $t->foreignId('bed_id')->nullable()->constrained('beds')->nullOnDelete();

            $t->string('request_status', 20)->default('PENDING'); // PENDING/ALLOCATED/CANCELLED
            $t->dateTime('requested_at');
            $t->dateTime('allocated_at')->nullable();
            $t->timestamps();

            $t->index(['ipd_admission_id', 'request_status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bed_requests');
    }
};
