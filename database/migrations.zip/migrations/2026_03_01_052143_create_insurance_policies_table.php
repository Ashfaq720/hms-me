<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('insurance_policies', function (Blueprint $t) {
            $t->id();
            $t->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();
            $t->foreignId('insurer_id')->constrained('insurers')->restrictOnDelete();

            $t->string('policy_no');
            $t->string('member_id')->nullable();
            $t->string('relationship_to_policyholder', 30)->default('SELF'); // SELF/SPOUSE/CHILD/PARENT/OTHER
            $t->date('valid_from')->nullable();
            $t->date('valid_to')->nullable();
            $t->boolean('cashless_supported')->default(false);
            $t->string('status', 20)->default('ACTIVE'); // ACTIVE/INACTIVE/EXPIRED
            $t->timestamps();

            $t->index(['patient_id', 'status']);
            $t->index(['valid_from', 'valid_to']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('insurance_policies');
    }
};
