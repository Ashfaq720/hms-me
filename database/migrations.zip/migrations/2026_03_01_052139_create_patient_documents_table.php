<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('patient_documents', function (Blueprint $t) {
            $t->id();
            $t->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();

            // Link documents to patient AND encounter context (Patient → Visit → Document)
            $t->string('reference_type', 20)->nullable(); // VISIT/IPD_ADMISSION/APPOINTMENT
            $t->unsignedBigInteger('reference_id')->nullable();

            $t->string('doc_type', 40); // ID_PROOF, INSURANCE_CARD_FRONT, INSURANCE_CARD_BACK, CORPORATE_CARD, CONSENT_SCAN, OTHER
            $t->string('file_path');
            $t->string('file_name')->nullable();
            $t->string('mime_type')->nullable();
            $t->unsignedInteger('file_size_kb')->nullable();

            $t->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $t->dateTime('uploaded_at')->nullable();

            $t->timestamps();
            $t->softDeletes(); // No hard delete

            $t->index(['patient_id', 'doc_type']);
            $t->index(['reference_type', 'reference_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('patient_documents');
    }
};
