<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('document_audit_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('document_id')->constrained('patient_documents')->cascadeOnDelete();
            $t->string('action', 20); // UPLOAD/VIEW/DOWNLOAD/DELETE_SOFT
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('ip_address')->nullable();
            $t->text('user_agent')->nullable();
            $t->dateTime('action_at');
            $t->timestamps();

            $t->index(['document_id', 'action_at']);
            $t->index(['action', 'action_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('document_audit_logs');
    }
};
