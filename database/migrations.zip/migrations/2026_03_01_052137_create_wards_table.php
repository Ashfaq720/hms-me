<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wards', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('code')->nullable()->unique();
            $t->string('ward_type', 20)->nullable(); // GENERAL/CABIN/ICU/HDU
            $t->timestamps();
            $t->unique(['name']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wards');
    }
};
