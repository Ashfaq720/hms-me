<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('encounter_coverages', function (Blueprint $t) {
            $t->id();
            $t->string('reference_type', 20); // VISIT/IPD_ADMISSION/APPOINTMENT/REGISTRATION
            $t->unsignedBigInteger('reference_id');

            $t->string('patient_type', 20)->default('SELF'); // SELF/INSURANCE/CORPORATE
            $t->foreignId('insurance_policy_id')->nullable()->constrained('insurance_policies')->nullOnDelete();
            $t->foreignId('corporate_agreement_id')->nullable()->constrained('corporate_agreements')->nullOnDelete();

            $t->string('cashless_status', 20)->default('NOT_ELIGIBLE'); // ELIGIBLE/PENDING/NOT_ELIGIBLE (system-controlled)
            $t->dateTime('verified_at')->nullable();
            $t->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();

            $t->boolean('locked_after_final_billing')->default(false);

            $t->timestamps();

            $t->unique(['reference_type', 'reference_id']);
            $t->index(['patient_type', 'cashless_status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('encounter_coverages');
    }
};
