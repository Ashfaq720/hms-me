<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('opd_patient_departments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();
            $table->string('case')->nullable(); // "case" is reserved in some contexts; ok as column but be careful in code
            $table->string('opd_number', 50)->unique();

            $table->decimal('height', 6, 2)->nullable(); // cm
            $table->decimal('weight', 6, 2)->nullable(); // kg
            $table->string('bp', 20)->nullable();         // e.g., 120/80

            $table->dateTime('appointment_date');

            $table->foreignId('doctor_id')->constrained('doctors')->restrictOnDelete();

            $table->decimal('standard_charge', 12, 2)->default(0);

            $table->string('payment_mode', 30); // Cash/Card/MFS/Bank/Insurance etc.

            $table->text('symptoms')->nullable();
            $table->text('notes')->nullable();

            $table->boolean('is_old_patient')->default(false);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('opd_patient_departmens');
    }
};
