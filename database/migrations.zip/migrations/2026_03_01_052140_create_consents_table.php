<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('consents', function (Blueprint $t) {
            $t->id();
            $t->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();

            $t->string('reference_type', 20)->nullable(); // VISIT/IPD_ADMISSION/PROCEDURE (future)
            $t->unsignedBigInteger('reference_id')->nullable();

            $t->string('consent_type', 100); // treatment/surgery/insurance/privacy
            $t->longText('consent_text')->nullable(); // snapshot text for legal
            $t->string('mode', 20)->default('DIGITAL'); // DIGITAL/SCANNED
            $t->dateTime('signed_at');                 // timestamped consent record
            $t->string('signature_path')->nullable();  // touch/mouse sign
            $t->string('guardian_name')->nullable();
            $t->string('witness_name')->nullable();
            $t->foreignId('captured_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();

            $t->index(['patient_id', 'signed_at']);
            $t->index(['reference_type', 'reference_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('consents');
    }
};
