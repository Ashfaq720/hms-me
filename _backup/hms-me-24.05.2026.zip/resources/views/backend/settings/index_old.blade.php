@extends('backend.layouts.master')

@section('title', 'Settings')

@section('content')
    <div class="container">
        <div class="app-page-head d-flex flex-wrap gap-3 align-items-center justify-content-between">
            <div class="clearfix">
                <h1 class="app-page-title">Settings</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="{{ route('dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Settings</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-underline card-header-tabs" id="settingsTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-bs-toggle="tab" href="#general">General</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#users">Users</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#appearance">Appearance</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#notifications">Notifications</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#integrations">Integrations</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#security">Security</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#backup">Backup</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#developer">Developer</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="general">
                                <h5 class="mb-3">General Settings</h5>
                                <form>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Website Name</label>
                                            <input type="text" class="form-control" placeholder="My Website">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Contact Email</label>
                                            <input type="email" class="form-control" placeholder="admin@example.com">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Logo Upload</label>
                                        <input type="file" class="form-control">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Timezone</label>
                                            <select class="form-select select2" data-placeholder="--Select Timezone--">
                                                <option value="UK">UK</option>
                                                <option value="UTC">UTC</option>
                                                <option value="America/New_York">America/New_York</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Language</label>
                                            <select class="form-select select2" data-placeholder="--Select Language--">
                                                <option value="English">English</option>
                                                <option value="USA">USA</option>
                                                <option value="French">French</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="users">
                                <h5 class="mb-3">User & Authentication</h5>
                                <form>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="twofa">
                                        <label class="form-check-label" for="twofa">Enable Two-Factor Authentication</label>
                                    </div>
                                    <div class="form-check mb-4">
                                        <input class="form-check-input" type="checkbox" id="socialLogin">
                                        <label class="form-check-label" for="socialLogin">Enable Social Logins (Google, FB)</label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Password Minimum Length</label>
                                        <input type="number" class="form-control" value="8">
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="appearance">
                                <h5 class="mb-3">Appearance</h5>
                                <form>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Theme Mode</label>
                                            <select class="form-select select2" data-placeholder="--Select Theme Mode--">
                                                <option value="Light">Light</option>
                                                <option value="Dark">Dark</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Font Family</label>
                                            <select class="form-select select2" data-placeholder="--Select Font Family--">
                                                <option value="Segoe UI">Segoe UI</option>
                                                <option value="Roboto">Roboto</option>
                                                <option value="Inter">Inter</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Primary Color</label>
                                            <input type="color" class="form-control form-control-color" value="#316AFF">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="notifications">
                                <h5 class="mb-3">Notifications</h5>
                                <form>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="emailNoti" checked>
                                        <label class="form-check-label" for="emailNoti">Email Notifications</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="pushNoti">
                                        <label class="form-check-label" for="pushNoti">Push Notifications</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="smsNoti">
                                        <label class="form-check-label" for="smsNoti">SMS Alerts</label>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="integrations">
                                <h5 class="mb-3">Integrations & APIs</h5>
                                <form>
                                    <div class="mb-3">
                                        <label class="form-label">Google Analytics ID</label>
                                        <input type="text" class="form-control" placeholder="UA-XXXXXXX">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Host</label>
                                        <input type="text" class="form-control" placeholder="smtp.example.com">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Payment Gateway Key</label>
                                        <input type="password" class="form-control" placeholder="********">
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="security">
                                <h5 class="mb-3">Security Settings</h5>
                                <form>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" id="captcha">
                                        <label class="form-check-label" for="captcha">Enable Captcha</label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Session Timeout (minutes)</label>
                                        <input type="number" class="form-control" value="30">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">IP Whitelist</label>
                                        <textarea class="form-control" rows="2" placeholder="192.168.1.1, 10.0.0.5"></textarea>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="tab-pane fade" id="backup">
                                <h5 class="mb-3">Data & Backup</h5>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-primary">Backup Now</button>
                                    <button class="btn btn-outline-secondary">Export Data</button>
                                    <button class="btn btn-outline-danger">Clear Cache</button>
                                </div>
                            </div>
                            
                            <div class="tab-pane fade" id="developer">
                                <h5 class="mb-3">Developer Settings</h5>
                                <form>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" id="debugMode">
                                        <label class="form-check-label" for="debugMode">Enable Debug Mode</label>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">API Key</label>
                                        <input type="text" class="form-control" placeholder="Enter API Key">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Webhook URL</label>
                                        <input type="url" class="form-control" placeholder="https://example.com/webhook">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
<!DOCTYPE html>
<html lang="en">

<head>

    <!-- begin::GXON Meta Basic -->
    <meta charset="utf-8">
    <meta name="theme-color" content="#316AFF">
    <meta name="robots" content="index, follow">
    <meta name="author" content="LayoutDrop">
    <meta name="format-detection" content="telephone=no">
    <meta name="keywords"
        content="HR Management, HR Dashboard, Admin Template, Admin Dashboard, Bootstrap Admin, HR Admin Panel, Employee Management, Human Resources Dashboard, Responsive Admin Template, Web App Dashboard, HRMS Admin, Staff Management Dashboard, Bootstrap 5 Admin, Modern Admin Template, Admin UI Kit, ThemeForest Admin Template, SaaS Dashboard, Project Management Admin, HR Web Application, RTL Dashboard">
    <meta name="description"
        content="GXON is a professional and modern HR Management Admin Dashboard Template built with Bootstrap. It includes light and dark modes, and is ideal for managing employees, attendance, payroll, recruitment, and more — perfect for HR software and admin panels.">
    <!-- end::GXON Meta Basic -->

    <!-- begin::GXON Meta Social -->
    <meta property="og:url" content="https://gxon.layoutdrop.com/demo/">
    <meta property="og:site_name" content="GXON HR Management Admin Dashboard Template + RTL">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="en_US">
    <meta property="og:title" content="GXON HR Management Admin Dashboard Template + RTL">
    <meta property="og:description"
        content="GXON is a professional and modern HR Management Admin Dashboard Template built with Bootstrap. It includes light and dark modes, and is ideal for managing employees, attendance, payroll, recruitment, and more — perfect for HR software and admin panels.">
    <meta property="og:image" content="https://gxon.layoutdrop.com/demo/preview.png">
    <!-- end::GXON Meta Social -->

    <!-- begin::GXON Meta Twitter -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:url" content="https://gxon.layoutdrop.com/demo/">
    <meta name="twitter:creator" content="@layoutdrop">
    <meta name="twitter:title" content="GXON HR Management Admin Dashboard Template + RTL">
    <meta name="twitter:description"
        content="GXON is a professional and modern HR Management Admin Dashboard Template built with Bootstrap. It includes light and dark modes, and is ideal for managing employees, attendance, payroll, recruitment, and more — perfect for HR software and admin panels.">
    <!-- end::GXON Meta Twitter -->

    <!-- begin::GXON Website Page Title -->
    <title>GXON HR Management Admin Dashboard Template + RTL</title>
    <!-- end::GXON Website Page Title -->

    <!-- begin::GXON Mobile Specific -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- end::GXON Mobile Specific -->

    <!-- begin::GXON Favicon Tags -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/apple-touch-icon.png">
    <!-- end::GXON Favicon Tags -->

    <!-- begin::GXON Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
        rel="stylesheet">
    <!-- end::GXON Google Fonts -->

    <!-- begin::GXON Required Stylesheet -->
    <link rel="stylesheet" href="assets/libs/flaticon/css/all/all.css">
    <link rel="stylesheet" href="assets/libs/lucide/lucide.css">
    <link rel="stylesheet" href="assets/libs/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="assets/libs/simplebar/simplebar.css">
    <link rel="stylesheet" href="assets/libs/node-waves/waves.css">
    <link rel="stylesheet" href="assets/libs/bootstrap-select/css/bootstrap-select.min.css">
    <!-- end::GXON Required Stylesheet -->

    <!-- begin::GXON CSS Stylesheet -->
    <link rel="stylesheet" href="assets/css/styles.css">
    <!-- end::GXON CSS Stylesheet -->



</head>

<body>
    <div class="page-layout">

        <!-- begin::GXON Page Header -->
        <header class="app-header">
            <div class="app-header-inner">
                <button class="app-toggler" type="button" aria-label="app toggler">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="app-header-start d-none d-md-flex">
                    <form class="d-flex align-items-center h-100 w-lg-250px w-xxl-300px position-relative"
                        action="#">
                        <button type="button" class="btn btn-sm border-0 position-absolute start-0 ms-3 p-0">
                            <i class="fi fi-rr-search"></i>
                        </button>
                        <input type="text" class="form-control rounded-5 ps-5" placeholder="Search anything's"
                            data-bs-toggle="modal" data-bs-target="#searchResultsModal">
                    </form>
                    <ul class="navbar-nav gap-4 flex-row d-none d-xxl-flex">
                        <li class="nav-item">
                            <a class="nav-link" href="analytics.html">Reports & Analytics</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="pages/faq.html">Help</a>
                        </li>
                    </ul>
                </div>
                <div class="app-header-end">
                    <div class="px-lg-3 px-2 ps-0 d-flex align-items-center">
                        <div class="dropdown">
                            <button
                                class="btn btn-icon btn-action-gray rounded-circle waves-effect waves-light position-relative"
                                id="ld-theme" type="button" data-bs-auto-close="outside" aria-expanded="false"
                                data-bs-toggle="dropdown">
                                <i class="fi fi-rr-brightness scale-1x theme-icon-active"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <button type="button" class="dropdown-item d-flex gap-2 align-items-center"
                                        data-bs-theme-value="light" aria-pressed="false">
                                        <i class="fi fi-rr-brightness scale-1x" data-theme="light"></i> Light
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="dropdown-item d-flex gap-2 align-items-center"
                                        data-bs-theme-value="dark" aria-pressed="false">
                                        <i class="fi fi-rr-moon scale-1x" data-theme="dark"></i> Dark
                                    </button>
                                </li>
                                <li>
                                    <button type="button" class="dropdown-item d-flex gap-2 align-items-center"
                                        data-bs-theme-value="auto" aria-pressed="true">
                                        <i class="fi fi-br-circle-half-stroke scale-1x" data-theme="auto"></i> Auto
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vr my-3"></div>
                    <div class="d-flex align-items-center gap-sm-2 gap-0 px-lg-4 px-sm-2 px-1">
                        <a href="email/inbox.html"
                            class="btn btn-icon btn-action-gray rounded-circle waves-effect waves-light position-relative">
                            <i class="fi fi-rr-envelope"></i>
                            <span
                                class="position-absolute top-0 end-0 p-1 mt-1 me-1 bg-danger border border-3 border-light rounded-circle">
                                <span class="visually-hidden">New alerts</span>
                            </span>
                        </a>
                        <div class="dropdown text-end">
                            <button type="button"
                                class="btn btn-icon btn-action-gray rounded-circle waves-effect waves-light"
                                data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="true">
                                <i class="fi fi-rr-bell"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-lg-end p-0 w-300px mt-2">
                                <div class="px-3 py-3 border-bottom d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">Notifications <span
                                            class="badge badge-sm rounded-pill bg-primary ms-2">9</span>
                                    </h6>
                                    <i class="bi bi-x-lg cursor-pointer"></i>
                                </div>
                                <div class="p-2" style="height: 300px;" data-simplebar>
                                    <ul class="list-group list-group-hover list-group-smooth list-group-unlined">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs avatar-status-success rounded-circle me-1">
                                                <img src="assets/images/avatar/avatar2.webp" alt="">
                                            </div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Emma Smith</h6>
                                                <small class="text-body d-block">Need to update the details.</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">7 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs bg-success rounded-circle text-white">D</div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Design Team</h6>
                                                <small class="text-body d-block">Check your shared folder.</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">6 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs bg-dark rounded-circle text-white">
                                                <i class="fi fi-rr-lock"></i>
                                            </div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Security Update</h6>
                                                <small class="text-body d-block">Password successfully set.</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">5 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs bg-info rounded-circle text-white">
                                                <i class="fi fi-rr-shopping-cart"></i>
                                            </div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Invoice #1432</h6>
                                                <small class="text-body d-block">has been paid Amount: $899.00</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">5 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs bg-danger rounded-circle text-white">R</div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Emma Smith</h6>
                                                <small class="text-body d-block">added you to Dashboard
                                                    Analytics</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">5 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs avatar-status-success rounded-circle me-1">
                                                <img src="assets/images/avatar/avatar3.webp" alt="">
                                            </div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Olivia Clark</h6>
                                                <small class="text-body d-block">You can now view the “Report”.</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">4 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="avatar avatar-xs avatar-status-danger rounded-circle me-1">
                                                <img src="assets/images/avatar/avatar5.webp" alt="">
                                            </div>
                                            <div class="ms-2 me-auto">
                                                <h6 class="mb-0">Isabella Walker</h6>
                                                <small class="text-body d-block">@Isabella please review.</small>
                                                <small class="text-muted position-absolute end-0 top-0 mt-2 me-3">2 hr
                                                    ago</small>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="p-2">
                                    <a href="javascript:void(0);"
                                        class="btn w-100 btn-primary waves-effect waves-light">View all
                                        notifications</a>
                                </div>
                            </div>
                        </div>
                        <a href="calendar.html"
                            class="btn btn-icon btn-action-gray rounded-circle waves-effect waves-light">
                            <i class="fi fi-rr-calendar"></i>
                        </a>
                    </div>
                    <div class="vr my-3"></div>
                    <div class="dropdown text-end ms-sm-3 ms-2 ms-lg-4">
                        <a href="#" class="d-flex align-items-center py-2" data-bs-toggle="dropdown"
                            data-bs-auto-close="outside" aria-expanded="true">
                            <div class="text-end me-2 d-none d-lg-inline-block">
                                <div class="fw-bold text-dark">Robert Brown</div>
                                <small class="text-body d-block lh-sm">
                                    <i class="fi fi-rr-angle-down text-3xs me-1"></i> Manager
                                </small>
                            </div>
                            <div class="avatar avatar-sm rounded-circle avatar-status-success">
                                <img src="assets/images/avatar/avatar1.webp" alt="">
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end w-225px mt-1">
                            <li class="d-flex align-items-center p-2">
                                <div class="avatar avatar-sm rounded-circle">
                                    <img src="assets/images/avatar/avatar1.webp" alt="">
                                </div>
                                <div class="ms-2">
                                    <div class="fw-bold text-dark">Robert Brown </div>
                                    <small class="text-body d-block lh-sm">robert@gmail.com</small>
                                </div>
                            </li>
                            <li>
                                <div class="dropdown-divider my-1"></div>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="profile.html">
                                    <i class="fi fi-rr-user scale-1x"></i> View Profile
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="task-management.html">
                                    <i class="fi fi-rr-note scale-1x"></i> My Task
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="pages/faq.html">
                                    <i class="fi fi-rs-interrogation scale-1x"></i> Help Center
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="settings.html">
                                    <i class="fi fi-rr-settings scale-1x"></i> Account Settings
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2" href="pages/pricing.html">
                                    <i class="fi fi-rr-usd-circle scale-1x"></i> Upgrade Plan
                                </a>
                            </li>
                            <li>
                                <div class="dropdown-divider my-1"></div>
                            </li>
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2 text-danger"
                                    href="authentication/login-basic.html">
                                    <i class="fi fi-sr-exit scale-1x"></i> Log Out
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- end::GXON Page Header -->

        <div class="modal fade" id="searchResultsModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header py-1 px-3">
                        <form class="d-flex align-items-center position-relative w-100" action="#">
                            <button type="button" class="btn btn-sm border-0 position-absolute start-0 p-0 text-sm ">
                                <i class="fi fi-rr-search"></i>
                            </button>
                            <input type="text" class="form-control form-control-lg ps-4 border-0 shadow-none"
                                id="searchInput" placeholder="Search anything's">
                        </form>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body pb-2" style="height: 300px;" data-simplebar>
                        <div id="recentlyResults">
                            <span class="text-uppercase text-2xs fw-semibold text-muted d-block mb-2">Recently
                                Searched:</span>
                            <ul class="list-inline search-list">
                                <li>
                                    <a class="search-item" href="index.html">
                                        <i class="fi fi-rr-apps"></i> Dashboard
                                    </a>
                                </li>
                                <li>
                                    <a class="search-item" href="chat.html">
                                        <i class="fi fi-rr-comment"></i> Chat
                                    </a>
                                </li>
                                <li>
                                    <a class="search-item" href="calendar.html">
                                        <i class="fi fi-rr-calendar"></i> Calendar
                                    </a>
                                </li>
                                <li>
                                    <a class="search-item" href="chart/apexchart.html">
                                        <i class="fi fi-rr-chart-pie-alt"></i> Apexchart
                                    </a>
                                </li>
                                <li>
                                    <a class="search-item" href="pages/pricing.html">
                                        <i class="fi fi-rr-file"></i> Pricing
                                    </a>
                                </li>
                                <li>
                                    <a class="search-item" href="email/inbox.html">
                                        <i class="fi fi-rr-envelope"></i> Email
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div id="searchContainer"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- begin::GXON Sidebar Menu -->
        <aside class="app-menubar" id="appMenubar">
            <div class="app-navbar-brand">
                <a class="navbar-brand-logo" href="index.html">
                    <img src="assets/images/logo.svg" alt="GXON Admin Dashboard Logo">
                </a>
                <a class="navbar-brand-mini visible-light" href="index.html">
                    <img src="assets/images/logo-text.svg" alt="GXON Admin Dashboard Logo">
                </a>
                <a class="navbar-brand-mini visible-dark" href="index.html">
                    <img src="assets/images/logo-text-white.svg" alt="GXON Admin Dashboard Logo">
                </a>
            </div>
            <nav class="app-navbar" data-simplebar>
                <ul class="menubar">
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-apps"></i>
                            <span class="menu-label">Dashboard</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="index.html">
                                    <span class="menu-label">Dashboard</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="index-rtl.html">
                                    <span class="menu-label">Dashboard RTL</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="ecommerce/ecommerce.html">
                                    <span class="menu-label">E-Commerce</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="employee.html">
                                    <span class="menu-label">Employee</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="attendance.html">
                                    <span class="menu-label">Attendance</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="leave.html">
                                    <span class="menu-label">Leave</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="payroll.html">
                                    <span class="menu-label">Payroll</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="recruitment.html">
                                    <span class="menu-label">Recruitment</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="task-management.html">
                                    <span class="menu-label">Task Management</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="analytics.html">
                                    <span class="menu-label">Analytics</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-heading">
                        <span class="menu-label">Apps & Pages</span>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="chat.html">
                            <i class="fi fi-rr-comment"></i>
                            <span class="menu-label">Chat</span>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="calendar.html">
                            <i class="fi fi-rr-calendar"></i>
                            <span class="menu-label">Calendar</span>
                        </a>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-envelope"></i>
                            <span class="menu-label">Email</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="email/inbox.html">
                                    <span class="menu-label">Inbox</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="email/compose.html">
                                    <span class="menu-label">Compose</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="email/read-email.html">
                                    <span class="menu-label">Read email</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-file"></i>
                            <span class="menu-label">Pages</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="pages/pricing.html">
                                    <span class="menu-label">Pricing</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="pages/faq.html">
                                    <span class="menu-label">FAQ's</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="pages/coming-soon.html">
                                    <span class="menu-label">Coming Soon</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="profile.html">
                                    <span class="menu-label">Profile</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="roles-permissions.html">
                                    <span class="menu-label">Roles Permissions</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="settings.html">
                                    <span class="menu-label">Settings</span>
                                </a>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Blog</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/blog.html">
                                            <span class="menu-label">Blog Grid</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/blog-list.html">
                                            <span class="menu-label">Blog List</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/blog-details.html">
                                            <span class="menu-label">Blog Details</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Error</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/error-404.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/error-404-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/error-404-full.html">
                                            <span class="menu-label">Full</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Under Construction</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/under-construction.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/under-construction-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="pages/under-construction-full.html">
                                            <span class="menu-label">Full</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-user-key"></i>
                            <span class="menu-label">Authentication</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Login</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/login-basic.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/login-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/login-frame.html">
                                            <span class="menu-label">Frame</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Register</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/register-basic.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/register-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/register-frame.html">
                                            <span class="menu-label">Frame</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Forgot Password</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/forgot-password-basic.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/forgot-password-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/forgot-password-frame.html">
                                            <span class="menu-label">Frame</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">New Password</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/new-password-basic.html">
                                            <span class="menu-label">Basic</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/new-password-cover.html">
                                            <span class="menu-label">Cover</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="authentication/new-password-frame.html">
                                            <span class="menu-label">Frame</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-heading">
                        <span class="menu-label">Components</span>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-flux-capacitor"></i>
                            <span class="menu-label">UI Components</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="components/accordion.html">
                                    <span class="menu-label">Accordion</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/alerts.html">
                                    <span class="menu-label">Alerts</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/badge.html">
                                    <span class="menu-label">Badge</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/breadcrumb.html">
                                    <span class="menu-label">Breadcrumb</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/buttons.html">
                                    <span class="menu-label">Buttons</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/typography.html">
                                    <span class="menu-label">Typography</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/button-group.html">
                                    <span class="menu-label">Button Group</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/card.html">
                                    <span class="menu-label">Card</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/collapse.html">
                                    <span class="menu-label">Collapse</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/carousel.html">
                                    <span class="menu-label">Carousel</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/dropdowns.html">
                                    <span class="menu-label">Dropdowns</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/modal.html">
                                    <span class="menu-label">Modal</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/navbar.html">
                                    <span class="menu-label">Navbar</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/list-group.html">
                                    <span class="menu-label">List Group</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/tabs.html">
                                    <span class="menu-label">Tabs</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/offcanvas.html">
                                    <span class="menu-label">Offcanvas</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/pagination.html">
                                    <span class="menu-label">Pagination</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/popovers.html">
                                    <span class="menu-label">Popovers</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/progress.html">
                                    <span class="menu-label">Progress</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/scrollspy.html">
                                    <span class="menu-label">Scrollspy</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/spinners.html">
                                    <span class="menu-label">Spinners</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/toasts.html">
                                    <span class="menu-label">Toasts</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="components/tooltips.html">
                                    <span class="menu-label">Tooltips</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-apps-add"></i>
                            <span class="menu-label">Extended UI</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/avatar.html">
                                    <span class="menu-label">Avatar</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/card-action.html">
                                    <span class="menu-label">Card action</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/drag-and-drop.html">
                                    <span class="menu-label">Drag & drop</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/simplebar.html">
                                    <span class="menu-label">Simplebar</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/swiper.html">
                                    <span class="menu-label">Swiper</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="extended-ui/team.html">
                                    <span class="menu-label">Team</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-bolt"></i>
                            <span class="menu-label">Icons</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="icons/flaticon.html">
                                    <span class="menu-label">Flaticon</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="icons/lucide.html">
                                    <span class="menu-label">Lucide</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="icons/fontawesome.html">
                                    <span class="menu-label">Font Awesome</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-heading">
                        <span class="menu-label">Forms & Tables</span>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-form"></i>
                            <span class="menu-label">Form Elements</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="forms/form-elements.html">
                                    <span class="menu-label">Form Elements</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/form-floating.html">
                                    <span class="menu-label">Form floating</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/form-input-group.html">
                                    <span class="menu-label">Form input group</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/form-layout.html">
                                    <span class="menu-label">Form layout</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/form-validation.html">
                                    <span class="menu-label">Form validation</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/flatpickr.html">
                                    <span class="menu-label">Flatpickr</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="forms/tagify.html">
                                    <span class="menu-label">Tagify</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-table-layout"></i>
                            <span class="menu-label">Table</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="table/tables-basic.html">
                                    <span class="menu-label">Table</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="table/tables-datatable.html">
                                    <span class="menu-label">Datatable</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-heading">
                        <span class="menu-label">Charts & Maps</span>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-chart-pie-alt"></i>
                            <span class="menu-label">Charts</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="chart/apexchart.html">
                                    <span class="menu-label">Apex Chart</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="chart/chartjs.html">
                                    <span class="menu-label">Chart JS</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rr-marker"></i>
                            <span class="menu-label">Maps</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item">
                                <a class="menu-link" href="maps/jsvectormap.html">
                                    <span class="menu-label">JS Vector Map</span>
                                </a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="maps/leaflet.html">
                                    <span class="menu-label">Leaflet</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-heading">
                        <span class="menu-label">Others</span>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="javascript:void(0);">
                            <i class="fi fi-rs-badget-check-alt"></i>
                            <span class="menu-label">Badge</span>
                            <span class="badge badge-sm rounded-pill bg-secondary ms-2 float-end">5</span>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="https://gxon.layoutdrop.com/doc/changelog.html" target="_blank">
                            <i class="fi fi-rr-square-terminal"></i>
                            <span class="menu-label">Changelog v1.3.0</span>
                        </a>
                    </li>
                    <li class="menu-item menu-arrow">
                        <a class="menu-link" href="javascript:void(0);" role="button">
                            <i class="fi fi-rs-floor-layer"></i>
                            <span class="menu-label">Multi Level</span>
                        </a>
                        <ul class="menu-inner">
                            <li class="menu-item menu-arrow">
                                <a class="menu-link" href="javascript:void(0);">
                                    <span class="menu-label">Multi Level 2</span>
                                </a>
                                <ul class="menu-inner">
                                    <li class="menu-item">
                                        <a class="menu-link" href="javascript:void(0);">
                                            <span class="menu-label">Multi Level 3</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="javascript:void(0);">
                                            <span class="menu-label">Multi Level 3</span>
                                        </a>
                                    </li>
                                    <li class="menu-item">
                                        <a class="menu-link" href="javascript:void(0);">
                                            <span class="menu-label">Multi Level 3</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <div class="app-footer">
                <a href="pages/faq.html" class="btn btn-outline-light waves-effect btn-shadow btn-app-nav w-100">
                    <i class="fi fi-rs-interrogation text-primary"></i>
                    <span class="nav-text">Help and Support</span>
                </a>
            </div>
        </aside>
        <!-- end::GXON Sidebar Menu -->

        <!-- begin::GXON Sidebar right -->
        <div class="app-sidebar-end">
            <ul class="sidebar-list">
                <li>
                    <a href="task-management.html">
                        <div
                            class="avatar avatar-sm bg-warning shadow-sharp-warning rounded-circle text-white mx-auto mb-2">
                            <i class="fi fi-rr-to-do"></i>
                        </div>
                        <span class="text-dark">Task</span>
                    </a>
                </li>
                <li>
                    <a href="pages/faq.html">
                        <div
                            class="avatar avatar-sm bg-secondary shadow-sharp-secondary rounded-circle text-white mx-auto mb-2">
                            <i class="fi fi-rr-interrogation"></i>
                        </div>
                        <span class="text-dark">Help</span>
                    </a>
                </li>
                <li>
                    <a href="calendar.html">
                        <div
                            class="avatar avatar-sm bg-info shadow-sharp-info rounded-circle text-white mx-auto mb-2">
                            <i class="fi fi-rr-calendar"></i>
                        </div>
                        <span class="text-dark">Event</span>
                    </a>
                </li>
                <li>
                    <a href="settings.html">
                        <div
                            class="avatar avatar-sm bg-gray shadow-sharp-gray rounded-circle text-white mx-auto mb-2">
                            <i class="fi fi-rr-settings"></i>
                        </div>
                        <span class="text-dark">Settings</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- end::GXON Sidebar right -->

        <main class="app-wrapper">

            <div class="container">

                <div class="app-page-head d-flex flex-wrap gap-3 align-items-center justify-content-between">
                    <div class="clearfix">
                        <h1 class="app-page-title">Settings</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item">
                                    <a href="index.html">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Settings</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <ul class="nav nav-underline card-header-tabs" id="settingsTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-bs-toggle="tab"
                                            href="#general">General</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#users">Users</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#appearance">Appearance</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab"
                                            href="#notifications">Notifications</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab"
                                            href="#integrations">Integrations</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#security">Security</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#backup">Backup</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-bs-toggle="tab" href="#developer">Developer</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="general">
                                        <h5 class="mb-3">General Settings</h5>
                                        <form>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Website Name</label>
                                                    <input type="text" class="form-control"
                                                        placeholder="My Website">
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Contact Email</label>
                                                    <input type="email" class="form-control"
                                                        placeholder="admin@example.com">
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Logo Upload</label>
                                                <input type="file" class="form-control">
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Timezone</label>
                                                    <select class="form-select select2" data-placeholder="--Select Timezone--">
                                                        <option value="UK">UK</option>
                                                        <option value="UTC">UTC</option>
                                                        <option value="America/New_York">America/New_York</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Language</label>
                                                    <select class="form-select select2" data-placeholder="--Select Language--">
                                                        <option value="English">English</option>
                                                        <option value="USA">USA</option>
                                                        <option value="French">French</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="users">
                                        <h5 class="mb-3">User & Authentication</h5>
                                        <form>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" id="twofa">
                                                <label class="form-check-label" for="twofa">Enable Two-Factor
                                                    Authentication</label>
                                            </div>
                                            <div class="form-check mb-4">
                                                <input class="form-check-input" type="checkbox" id="socialLogin">
                                                <label class="form-check-label" for="socialLogin">Enable Social
                                                    Logins (Google, FB)</label>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Password Minimum Length</label>
                                                <input type="number" class="form-control" value="8">
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="appearance">
                                        <h5 class="mb-3">Appearance</h5>
                                        <form>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Theme Mode</label>
                                                    <select class="form-select select2" data-placeholder="--Select Theme Mode--">
                                                        <option value="Light">Light</option>
                                                        <option value="Dark">Dark</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Font Family</label>
                                                    <select class="form-select select2" data-placeholder="--Select Font Family--">
                                                        <option value="Segoe UI">Segoe UI</option>
                                                        <option value="Roboto">Roboto</option>
                                                        <option value="Inter">Inter</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Primary Color</label>
                                                    <input type="color" class="form-control form-control-color"
                                                        value="#316AFF">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="notifications">
                                        <h5 class="mb-3">Notifications</h5>
                                        <form>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" id="emailNoti"
                                                    checked>
                                                <label class="form-check-label" for="emailNoti">Email
                                                    Notifications</label>
                                            </div>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" id="pushNoti">
                                                <label class="form-check-label" for="pushNoti">Push
                                                    Notifications</label>
                                            </div>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" id="smsNoti">
                                                <label class="form-check-label" for="smsNoti">SMS Alerts</label>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="integrations">
                                        <h5 class="mb-3">Integrations & APIs</h5>
                                        <form>
                                            <div class="mb-3">
                                                <label class="form-label">Google Analytics ID</label>
                                                <input type="text" class="form-control"
                                                    placeholder="UA-XXXXXXX">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">SMTP Host</label>
                                                <input type="text" class="form-control"
                                                    placeholder="smtp.example.com">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Payment Gateway Key</label>
                                                <input type="password" class="form-control"
                                                    placeholder="********">
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="security">
                                        <h5 class="mb-3">Security Settings</h5>
                                        <form>
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="checkbox" id="captcha">
                                                <label class="form-check-label" for="captcha">Enable
                                                    Captcha</label>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Session Timeout (minutes)</label>
                                                <input type="number" class="form-control" value="30">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">IP Whitelist</label>
                                                <textarea class="form-control" rows="2" placeholder="192.168.1.1, 10.0.0.5"></textarea>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="tab-pane fade" id="backup">
                                        <h5 class="mb-3">Data & Backup</h5>
                                        <button class="btn btn-primary me-2">Backup Now</button>
                                        <button class="btn btn-outline-secondary me-2">Export Data</button>
                                        <button class="btn btn-outline-danger">Clear Cache</button>
                                    </div>
                                    <div class="tab-pane fade" id="developer">
                                        <h5 class="mb-3">Developer Settings</h5>
                                        <form>
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="checkbox" id="debugMode">
                                                <label class="form-check-label" for="debugMode">Enable Debug
                                                    Mode</label>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">API Key</label>
                                                <input type="text" class="form-control"
                                                    placeholder="Enter API Key">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Webhook URL</label>
                                                <input type="url" class="form-control"
                                                    placeholder="https://example.com/webhook">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </main>

        <!-- begin::GXON Footer -->
        <footer class="footer-wrapper bg-body">
            <div class="container">
                <div class="row g-2">
                    <div class="col-lg-6 col-md-7 text-center text-md-start">
                        <p class="mb-0">© <span class="currentYear">2025</span> GXON. Proudly powered by <a
                                href="javascript:void(0);">LayoutDrop</a>.</p>
                    </div>
                    <div class="col-lg-6 col-md-5">
                        <ul
                            class="d-flex list-inline mb-0 gap-3 flex-wrap justify-content-center justify-content-md-end">
                            <li>
                                <a class="text-body" href="index.html">Home</a>
                            </li>
                            <li>
                                <a class="text-body" href="pages/faq.html">Faq's</a>
                            </li>
                            <li>
                                <a class="text-body" href="pages/faq.html">Support</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end::GXON Footer -->

    </div>

    <!-- begin::GXON Page Scripts -->
    <script src="assets/libs/global/global.min.js"></script>
    <script src="assets/js/appSettings.js"></script>
    <script src="assets/js/main.js"></script>
    <!-- end::GXON Page Scripts -->
</body>

</html>
